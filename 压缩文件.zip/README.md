api
user.go #和用户相关的api接口
article.go #和文章相关的api接口
comment.go #和评论相关的api接口
database
user.go #用户数据库操作相关的代码
aritcle.go #文章数据库相关的代码
comment.go #评论数据库相关的代码
model
user.go #用户相关模型
aritcle.go #文章相关模型
comment .go #评论相关模型
repository
user.go #用户存储接口和实现
aritcle.go #文章存储接口和实现
comment.go #评论存储接口和实现
service
user.go #用户服务代码
aritcle.go #文章服务代码
comment.go #评论服务代码
utils
valid.go #一些安全措施
