package utils

//import (
//	"io"
//	"strconv"
//)
//
//func BodyToInit(body io.Reader) (int, error) {
//	data, err := io.ReadAll(body)
//	if err != nil {
//		return 0, err
//	}
//
//	value, err := strconv.Atoi(string(data))
//	if err != nil {
//		return 0, err
//	}
//
//	return value, nil
//}
