package api

import "go-web/service"

var UserService service.UserServiceImpl
var ArticleServer service.ArticleImpl
