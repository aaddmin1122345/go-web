package model

type SessionModel struct {
	ID         string
	UserName   string
	SessionKey string
	Expiration string
}
