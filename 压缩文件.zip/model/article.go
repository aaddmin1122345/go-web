package model

type Article struct {
	ID         int
	Title      string
	Content    string
	Date       string
	CreateTime string
	ImageURL   string
	Category   string
}
